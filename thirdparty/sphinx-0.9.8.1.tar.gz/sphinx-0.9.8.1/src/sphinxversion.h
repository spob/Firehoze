#define SPH_SVN_TAG "rel098"
#define SPH_SVN_REV 1533
#define SPH_SVN_REVSTR "1533"
#define SPH_SVN_TAGREV "rel098-r1533"
